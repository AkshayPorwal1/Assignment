import { Component, OnInit, EventEmitter,Output } from '@angular/core';

import { MatTableDataSource } from '@angular/material/table';
import {EmpDataInterface} from '../empData.model'
import { FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-mat-table',
  templateUrl: './mat-table.component.html',
  styleUrls: ['./mat-table.component.css']
})


export class MatTableComponent implements OnInit {
  gender: string[] = ["Male","Female","others"];
  city: string[] = ["dummytxt1", "dummytxt2", "dummytxt3", "dummytxt4"];
  state: string[] = ["dummytxt1", "dummytxt2", "dummytxt3", "dummytxt4"];
  options: string [] = ["Dummytxt1", "Dummytxt2", "Dummytxt3", "Dummytxt4"];
  empform: FormGroup;
  disabledValid;
  private srno:number=1;
  private delId:number=null;
  private patchData;
  private employeees:EmpDataInterface[]=[
  {
  srNo: this.srno, firstname: 'dummytext', lastName: 'dummytext', email: 'dummytext',
  phone:7770998612,date:'5/7/20',gender:'Male',city:'dummytxt1',state:'dummytxt1',age:23,
  address:'dummytext',options:'Dummytxt2'
  }
  ];
  displayedColumns: string[] = ['srNo','firstname', 'lastName', 'email', 'phone','date',
                               'gender','city','state','age','address','options','action'];
  dataSource = new MatTableDataSource<EmpDataInterface>(this.employeees);
  
  constructor(private fbd: FormBuilder) {
    
  }
 
  ngOnInit() {
    this.empform = this.fbd.group({
      firstname: ['',Validators.required],
      lastName: ['',Validators.required],
      email: ['',Validators.required],
      phone: ['',Validators.required],
      date: ['',Validators.required],
      gender: ['',Validators.required],
      city: ['',Validators.required],
      state: ['',Validators.required],
      age:['',Validators.required],
      address: ['',Validators.required],
      options:['',Validators.required]
    });
    
  }
  
  edit(eleId:EmpDataInterface){
    this.patchData=eleId;
    this.empform.patchValue({ 
      firstname:this.patchData.firstname,
      lastName: this.patchData.lastName,
      email: this.patchData.email,
      phone: this.patchData.phone,
      date: this.patchData.date,
      gender:this.patchData.gender,
      city: this.patchData.city,
      state: this.patchData.state,
      age: this.patchData.age,
      address:this.patchData.address,
      options:this.patchData.options
    });
    this.delId=this.employeees.indexOf(eleId);
    this.employeees.splice(this.delId,1)
    this.dataSource = new MatTableDataSource(this.employeees);
    this.managesrno();
  }
  del(eleId){
    this.delId=this.employeees.indexOf(eleId);
    this.employeees.splice(this.delId,1)
    this.dataSource = new MatTableDataSource(this.employeees);
    this.managesrno();
  }
  getsrno():number{
    this.srno=this.srno+1;
    return this.srno;
  }
  managesrno():number{
    if(this.srno!==1)
    this.srno=this.srno-1;
    return this.srno;
  }
  onSubmit(){
    let newEmployee: EmpDataInterface = {
          srNo:this.getsrno(),
          firstname: this.empform.get('firstname').value,
          lastName: this.empform.get('lastName').value,
          email: this.empform.get('email').value,
          phone: this.empform.get('phone').value,
          date: this.empform.get('date').value,
          gender: this.empform.get('gender').value,
          city: this.empform.get('city').value,
          state: this.empform.get('state').value,
          age:this.empform.get('age').value,
          address:this.empform.get('address').value,
          options:this.empform.get('options').value
        };
    this.employeees.push(newEmployee);  
    this.dataSource = new MatTableDataSource(this.employeees);
  }
}
