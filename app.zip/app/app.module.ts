import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import {MaterialModule} from './material/material.module'
import { MatTableComponent } from './mat-table/mat-table.component';


@NgModule({
  imports:      [ BrowserModule,BrowserAnimationsModule, FormsModule,MaterialModule, ReactiveFormsModule],
  declarations: [ AppComponent, MatTableComponent ],
  bootstrap:    [ AppComponent ],
  providers: []
})
export class AppModule { }
