export interface EmpDataInterface {
  srNo: number;  
  firstname: string;
  lastName: string;
  email: string;
  phone: number;
  date: string;
  gender: string;
  city: string;
  state: string;
  age: number;
  address:string;
  options:string;
}
